import { GoogleGenAI, Type } from "@google/genai";
import { EdTechReport } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

export async function generatePulseReport(input: any): Promise<EdTechReport> {
  const rawData = input.data || input || [];
  
  if (!Array.isArray(rawData) || rawData.length === 0) {
    throw new Error("No fresh updates in the last 24 hours to analyze.");
  }

  const prompt = `
    You are an expert Market Intelligence Analyst for an EdTech company called "Campus Cortex AI".
    Your task is to analyze raw, unstructured text data collected from tech news articles, blogs, and RSS feeds from the last 24–48 hours and convert it into a concise, structured "Morning Pulse" report for the CEO.

    TARGET DATA:
    ${JSON.stringify(rawData)}

    🎯 OBJECTIVE:
    Extract meaningful, high-impact insights and categorize them into:
    1. Competitor Updates
    2. User Pain Points
    3. Emerging Tech Trends

    For EVERY item extracted, specify the "source" from where it was derived.

    ⚠️ STRICT RULES:
    - ONLY use the provided input data.
    - DO NOT hallucinate or invent information.
    - IGNORE irrelevant industries.
    - REJECT & REMOVE any data related to: Exam results, school/college events, admissions, scholarships, or political news.
    - Return ONLY structured JSON.
  `;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            competitor_updates: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  title: { type: Type.STRING },
                  insight: { type: Type.STRING },
                  impact: { type: Type.STRING },
                  source: { type: Type.STRING }
                },
                required: ["title", "insight", "impact", "source"]
              }
            },
            user_pain_points: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  issue: { type: Type.STRING },
                  details: { type: Type.STRING },
                  frequency: { type: Type.STRING, enum: ["Low", "Medium", "High"] },
                  source: { type: Type.STRING }
                },
                required: ["issue", "details", "frequency", "source"]
              }
            },
            emerging_tech_trends: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  trend: { type: Type.STRING },
                  description: { type: Type.STRING },
                  opportunity: { type: Type.STRING },
                  source: { type: Type.STRING }
                },
                required: ["trend", "description", "opportunity", "source"]
              }
            }
          },
          required: ["competitor_updates", "user_pain_points", "emerging_tech_trends"]
        }
      }
    });

    const result = JSON.parse(response.text || '{}');
    return {
      ...result,
      timestamp: new Date().toISOString()
    };
  } catch (error: any) {
    console.error("Gemini AI Error:", error);
    // Standardize quota error check
    if (error?.message?.includes("quota") || (error?.status === 429)) {
      throw new Error("QUOTA_EXCEEDED");
    }
    throw error;
  }
}
