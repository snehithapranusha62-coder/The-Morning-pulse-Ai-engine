
export interface User {
  id: number;
  school_name: string;
  principal_name: string;
  contact_number: string;
  email: string;
}

export interface EdTechReport {
  date?: string;
  executive_summary?: string;
  competitor_updates: CompetitorUpdate[];
  user_pain_points: UserPainPoint[];
  emerging_tech_trends: EmergingTechTrend[];
  timestamp?: string; // Kept for legacy if needed or internal use
}

export interface CompetitorUpdate {
  title: string;
  insight: string;
  impact: string;
  source?: string;
  sentiment?: 'positive' | 'neutral' | 'negative';
}

export interface UserPainPoint {
  issue: string;
  details: string;
  frequency: 'Low' | 'Medium' | 'High';
  source?: string;
  sentiment?: 'positive' | 'neutral' | 'negative';
}

export interface EmergingTechTrend {
  trend: string;
  description: string;
  opportunity: string;
  source?: string;
  sentiment?: 'positive' | 'neutral' | 'negative';
}
